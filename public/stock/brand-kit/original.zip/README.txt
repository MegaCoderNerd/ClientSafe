Lumen Studio — brand kit
ClientVault demo original (unlocked after payment)

Files
- logo.svg
- mark.svg
- colors.json

This is a stock demo package for testing preview vs original delivery.
