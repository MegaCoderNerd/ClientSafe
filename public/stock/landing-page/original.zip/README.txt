North Harbor Coffee — landing page source
ClientVault demo original (unlocked after payment)

Files
- index.html
- styles.css

This is a stock demo package for testing preview vs original delivery.
